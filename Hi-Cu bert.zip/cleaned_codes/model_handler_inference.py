import torch
import torch.nn as nn
import logging as lg
from utils.data_utils_context_only_mod import prepare_datasets as prepare_datasets_c
from utils.data_utils_hist_only_mod import prepare_datasets as prepare_datasets_h
from torch.utils.tensorboard import SummaryWriter
from utils.eval_utils import AverageMeter
from model_h_c_inference import Model
from transformers import *
import time
import os

MODELS = {'RoBERTa':(RobertaModel,    RobertaTokenizer,  'roberta-base')}


class ModelHandler2():
	def __init__(self, config):
		lg.basicConfig(filename='train_logs.log', level = lg.WARNING)
		self.tb = SummaryWriter()
		self.config = config
		tokenizer_model = MODELS[config['model_name']]
		tokenizer = tokenizer_model[1].from_pretrained("saved_tokenizer")

		#context loader
		self.train_loader, self.dev_loader, self.test_loader, tokenizer = prepare_datasets_c(config, tokenizer)
		#history loader
		self.train_loader2, self.dev_loader2, self.test_loader2, tokenizer = prepare_datasets_h(config, tokenizer)
		self._n_dev_batches = len(self.dev_loader.dataset) // config['batch_size']
		self._n_train_batches = len(self.train_loader.dataset) // config['batch_size']
		if config['cuda']:
			self.device = torch.device('cuda')
		else:
			self.device = torch.device('cpu')

		self._train_loss = AverageMeter()
		self._train_f1 = AverageMeter()
		self._train_em = AverageMeter()
		self._dev_f1 = AverageMeter()
		self._dev_em = AverageMeter()

		self.model = Model(config, MODELS[config['model_name']],MODELS[config['model_name']], self.device, tokenizer).to(self.device)
		self.optimizer = AdamW(self.model.parameters(), lr=config['lr'], eps = config['adam_epsilon'] )
		self.optimizer.zero_grad()
		self._n_train_examples = 0
		self._epoch = self._best_epoch = 0
		self._best_f1 = 0
		self._best_em = 0
		self.restored = False
		if config['pretrained_dir'] is not None:
			self.restore()
	def train(self):
		print("\n>>> Validation Epoch: [{} / {}]".format(self._epoch, self.config['max_epochs']))
		self._run_epoch(self.dev_loader,self.dev_loader2, training=False, verbose=self.config['verbose'], save = False)
		
		format_str = "Validation Epoch {} -- F1: {:0.2f}, EM: {:0.2f} --"
		print(format_str.format(self._epoch, self._dev_f1.mean(), self._dev_em.mean()))
		self._best_f1 = self._dev_f1.mean()
		self._best_em = self._dev_em.mean()
		for i in range(self.config['max_epochs']):
			self._epoch += 1
			print("\n>>> Train Epoch: [{} / {}]".format(self._epoch, self.config['max_epochs']))
			if not self.restored:
				self.train_loader.prepare()	
				self.train_loader2.prepare() 
			self.restored = False
			print("------------------------LOGGING AGAIN--------------------------------")
			lg.debug("Adding Logs for train")
			self._run_epoch(self.train_loader,self.train_loader2, training=True, verbose=self.config['verbose'], save=True)
			format_str = "Training Epoch {} -- Loss: {:0.4f}, F1: {:0.2f}, EM: {:0.2f} --"
			self.tb.add_scalar("train Loss haice", self._train_loss.mean(), self._epoch)
			self.tb.add_scalar("train F1 haice", self._train_f1.mean(), self._epoch)
			print(format_str.format(self._epoch, self._train_loss.mean(),
			self._train_f1.mean(), self._train_em.mean()))
			lg.warning(format_str.format(self._epoch, self._train_loss.mean(),self._train_f1.mean(), self._train_em.mean()))
			print("\n>>> Validation Epoch: [{} / {}]".format(self._epoch, self.config['max_epochs']))
			self.dev_loader.prepare()
			self.dev_loader2.prepare()
			self._run_epoch(self.dev_loader,self.dev_loader2, training=False, verbose=self.config['verbose'], save = False)
			self.tb.add_scalar("Validation F1 haice", self._dev_f1.mean(), self._epoch)
			
			format_str = "Validation Epoch {} -- F1: {:0.2f}, EM: {:0.2f} --"
			print(format_str.format(self._epoch, self._dev_f1.mean(), self._dev_em.mean()))
			
			if self._best_f1 <= self._dev_f1.mean():
			    self._best_epoch = self._epoch
			    self._best_f1 = self._dev_f1.mean()
			    self._best_em = self._dev_em.mean()
			    print("!!! Updated: F1: {:0.2f}, EM: {:0.2f}".format(self._best_f1, self._best_em))
			self._reset_metrics()
			self.save(self._epoch)
		print("Testing")
		self.test_loader.prepare()
		self.test_loader2.prepare()
		self._run_epoch(self.test_loader,self.test_loader2, training=False, out_predictions=True, verbose=self.config['verbose'], save = False)
		format_str = "Test Epoch -- F1: {:0.2f}, EM: {:0.2f} --"
		print(format_str.format(self._dev_f1.mean(), self._dev_em.mean()))
	#not added code for history/context model in restore
	def restore(self):
		if not os.path.exists(self.config['pretrained_dir']):
			print('dir doesn\'t exists, cannot restore')
			return
		print("restoring")
		restored_params = torch.load(self.config['pretrained_dir']+'/latest/model.pth')
		self.model.load_state_dict(restored_params['model'])
		self.optimizer.load_state_dict(restored_params['optimizer'])
		self._epoch = restored_params['epoch']
		self._best_epoch = restored_params['best_epoch']
		self._n_train_examples = restored_params['train_examples']
		self._best_f1 = restored_params['best_f1']
		self._best_em = restored_params['best_em']
		examples = restored_params['dataloader_examples']
		batch_state = restored_params['dataloader_batch_state']
		state = restored_params['dataloader_state']
		self.train_loader.restore(examples, state, batch_state)
		self.train_loader2.restore(examples,state,batch_state)

		self.restored = True

	def save(self, save_epoch_val):
		if not os.path.exists(self.config['save_state_dir']):
			os.mkdir(self.config['save_state_dir'])
		
		# if self._best_epoch == self._epoch:
		if self._epoch % 10 == 0:
			if not os.path.exists(self.config['save_state_dir']+'/best'):
				os.mkdir(self.config['save_state_dir']+'/best')
			save_dic = {'epoch':self._epoch,
			'best_epoch': self._best_epoch,
			'train_examples':self._n_train_examples,
			'model':self.model.state_dict(),
			'optimizer':self.optimizer.state_dict(),
			'best_f1':self._best_f1,
			'best_em':self._best_em}
			torch.save(save_dic, self.config['save_state_dir']+'/best/model.pth')
		if not os.path.exists(self.config['save_state_dir']+'/latest'):
			os.mkdir(self.config['save_state_dir']+'/latest')
		save_dic = {'epoch':save_epoch_val,
			'best_epoch': self._best_epoch,
			'train_examples':self._n_train_examples,
			'model':self.model.state_dict(),
			'optimizer':self.optimizer.state_dict(),
			'best_f1':self._best_f1,
			'best_em':self._best_em,
			'dataloader_batch_state': self.train_loader.batch_state,
			'dataloader_state':self.train_loader.state,
			'dataloader_examples':self.train_loader.examples}
		torch.save(save_dic, self.config['save_state_dir']+'/latest/model.pth')

	def _run_epoch(self, data_loader,data_loader2, training=True, verbose=10, out_predictions=False, save = False):
			start_time = time.time()
			print(f"Current Batch_state: {data_loader.batch_state} and len of data_loader is {len(data_loader)}")
			print(f"Current Batch_state2: {data_loader2.batch_state} and len of data_loader2 is {len(data_loader2)}")
			while data_loader.batch_state < len(data_loader):
					input_batch = data_loader.get()
					input_batch2 = data_loader2.get()

					res = self.model(input_batch, input_batch2, training)

					tr_loss = 0
					if training:
						loss = res['loss']
						if self.config['gradient_accumulation_steps'] > 1:
							loss = loss / self.config['gradient_accumulation_steps']
						tr_loss = loss.mean().item()
					start_logits = res['start_logits']
					end_logits = res['end_logits']
					if training:
						self.model.update(loss, self.optimizer, data_loader.batch_state)

					paragraphs = [inp['tokens'] for inp in input_batch]
					
					
					answers = [inp['answer'] for inp in input_batch]
					f1, em, predictions = self.model.evaluate(start_logits, end_logits, paragraphs, answers)
					if out_predictions:
						print("predictions = {}, answer = {}, context = {}".format(predictions, answers, paragraphs))
					self._update_metrics(tr_loss, f1, em, len(paragraphs), training=training)
					if training:
							self._n_train_examples += len(paragraphs)
					if data_loader.batch_state == self._n_train_batches:
							if save:
								print("------------saving------------")
								self.save(self._epoch - 1)
					if verbose > 0:
							mode = "train" if training else "dev"
							print(self.report(data_loader.batch_state, tr_loss, f1 * 100, em * 100, mode))
							print('used_time: {:0.2f}s'.format(time.time() - start_time))

	def _update_metrics(self, loss, f1, em, batch_size, training=True):
		if training:
			self._train_loss.update(loss)
			self._train_f1.update(f1 * 100, batch_size)
			self._train_em.update(em * 100, batch_size)
		else:
			self._dev_f1.update(f1 * 100, batch_size)
			self._dev_em.update(em * 100, batch_size)

	def _reset_metrics(self):
		self._train_loss.reset()
		self._train_f1.reset()
		self._train_em.reset()
		self._dev_f1.reset()
		self._dev_em.reset()
	def report(self, step, loss, f1, em, mode='train'):
		if mode == "train":
		    format_str = "[train-{}] step: [{} / {}] | exs = {} | loss = {:0.4f} | f1 = {:0.2f} | em = {:0.2f}"
		    return format_str.format(self._epoch, step, self._n_train_batches, self._n_train_examples, loss, f1, em)
		elif mode == "dev":
		    return "[predict-{}] step: [{} / {}] | f1 = {:0.2f} | em = {:0.2f}".format(
		            self._epoch, step, self._n_dev_batches, f1, em)
		elif mode == "test":
		    return "[test] | test_exs = {} | step: [{} / {}] | f1 = {:0.2f} | em = {:0.2f}".format(
		            self._n_test_examples, step, self._n_test_batches, f1, em)
		else:
			raise ValueError('mode = {} not supported.' % mode)
	def _stop_condition(self, epoch):
		"""
		Checks have not exceeded max epochs and has not gone 10 epochs without improvement.
		"""
		no_improvement = epoch >= self._best_epoch + 10
		exceeded_max_epochs = epoch >= self.config['max_epochs']
		return False if exceeded_max_epochs or no_improvement else True