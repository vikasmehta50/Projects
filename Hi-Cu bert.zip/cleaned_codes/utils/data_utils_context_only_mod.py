import json
import io
from torch.utils.data import DataLoader
from torch.utils.data import Dataset
from collections import Counter, defaultdict
import numpy as np
from random import shuffle
import math
import textacy.preprocessing.replace as rep
from tqdm import tqdm                                                               
import spacy
nlp = spacy.load('en_core_web_sm')

def prepare_datasets(config, tokenizer):
    trainset = CoQADataset(config['trainset'], tokenizer, train="train")
    trainloader = CustomDataLoader(trainset, config['batch_size'])
    devset = CoQADataset(config['devset'], tokenizer, train="dev")
    devloader = CustomDataLoader(devset, config['batch_size'])
    testset = CoQADataset(config['testset'], tokenizer, train="test")
    testloader = CustomDataLoader(testset, config['batch_size'])
    return trainloader, devloader, testloader, tokenizer
def get_file_contents(filename, encoding='utf-8'):
    with io.open(filename, encoding=encoding) as f:
        content = f.read()
    f.close()
    return content


def read_json(filename, encoding='utf-8'):
    contents = get_file_contents(filename, encoding=encoding)
    return json.loads(contents)

# This class was created entirely by our team
# It creates the input for the context model. COncatenating the current question and the context together
# Then add the words to the tokenizer.
class CoQADataset(Dataset):
    """CoQA dataset."""

    def __init__(self, filename, tokenizer, train="train"):
        self.filename = filename
        paragraph_lens = []
        question_lens = []
        self.paragraphs = []
        self.examples = []
        self.chunked_examples = []
        self.vocab = Counter()
        dataset = read_json(filename)
        customcounter = 0
        print("------------------DATASET SIZE -------------")
        print(len(dataset['data']))
        for group in tqdm(dataset['data']):
            customcounter += 1
            for qa in group['qas']:
                temp = []
                temp.append('<s>')
                temp.append('<Q>')
                temp.extend(qa['annotated_question']['word'])
                temp.extend(['</s>', '</s>'])
                q_len = len(temp)
                start = qa['answer_span'][0] + q_len
                end = qa['answer_span'][1] + q_len
                temp.extend(group['annotated_context']['word'])
                yes_index = len(temp)
                no_index = yes_index + 1
                temp.extend(['yes', 'no', '</s>'])
                if qa['answer'] == 'yes' and temp[start] != 'yes':
                    start = yes_index
                    end = yes_index
                if qa['answer'] == 'no' and temp[start] != 'no':
                    start = no_index
                    end = no_index

                tokens = temp
                input_mask = [1] * len(tokens)
                input_mask.extend([0] * (512 - len(tokens)))
                input_ids = tokenizer.convert_tokens_to_ids(tokens)
                input_ids.extend([0]*(512 - len(tokens)))
                segment_ids = []
                tokenizer.add_tokens(tokens)
                _examples = {'tokens': tokens, 'answer':tokens[start : end+1],'actual_answer':qa['answer'] ,'input_tokens':input_ids, 'input_mask':input_mask, 'segment_ids':segment_ids, 'start':start, 'end':end}
                self.chunked_examples.append(_examples)
            
    def __len__(self):
        return len(self.chunked_examples)

    def __getitem__(self, idx):
        return self.chunked_examples[idx]

class CustomDataLoader:
    def __init__(self, dataset, batch_size):
        self.dataset = dataset
        self.batch_size = batch_size
        self.state = 0
        self.batch_state = 0
        self.examples = [i for i in range(len(self.dataset))]
        self.current_view = []
    def __len__(self):
        return math.ceil(len(self.examples)/self.batch_size)
    def prepare(self):
        shuffle(self.examples)
        self.state = 0
        self.batch_state = 0

    def restore(self, examples, state, batch_state):
        self.examples = examples
        self.state = state
        self.batch_state = batch_state
    
    def get(self):
        data_view = []
        for i in range(self.batch_size):
            if self.state + i < len(self.examples):
                data_view.append(self.dataset[self.examples[self.state + i]])
        self.state += self.batch_size
        self.batch_state+=1
        return data_view


if __name__=='__main__':
    from transformers import *
    MODELS = {'RoBERTa':(RobertaModel,    RobertaTokenizer,    'roberta-base')}
          
    tokenizer_model = MODELS['RoBERTa']
    tokenizer = tokenizer_model[1].from_pretrained(tokenizer_model[2])
