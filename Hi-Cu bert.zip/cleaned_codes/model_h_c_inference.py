import torch
import torch.nn as nn
from utils.eval_utils import compute_eval_metric
from transformers import *
import numpy as np
from torch.utils.tensorboard import SummaryWriter


class Model(nn.Module):
	def __init__(self, config, model,model2, device, tokenizer):
		super(Model, self).__init__()

		self.device = device
		self.config = config

		if config['model_path'] is not None:
			self.pretrained_model = model[0].from_pretrained(config['model_path']).to(device)
			self.pretrained_model2 = model2[0].from_pretrained(config['model_path']).to(device)
		else:
			self.pretrained_model = model[0].from_pretrained(model[2]).to(device)
			self.pretrained_model2 = model[0].from_pretrained(model[2]).to(device)

		self.pretrained_model.resize_token_embeddings(len(tokenizer))
		self.pretrained_model.train()

		self.pretrained_model2.resize_token_embeddings(len(tokenizer))
		self.pretrained_model2.train()



		self.qa_outputs = nn.Linear(768, 2)

		self.num_heads = 3
		self.embed_dim = 64*self.num_heads
		self.q = nn.Linear(768, 64*self.num_heads)
		self.k = nn.Linear(768, 64*self.num_heads)
		self.v = nn.Linear(768, 64*self.num_heads)
		self.op = nn.Linear(64*self.num_heads, 768)
		self.multihead_attn = nn.MultiheadAttention(self.embed_dim, self.num_heads, batch_first=True)

	def forward(self, inputs,inputs2, train = True):
		input_ids = torch.tensor([inp['input_tokens'] for inp in inputs], dtype = torch.long).to(self.device)
		input_mask = torch.tensor([inp['input_mask'] for inp in inputs], dtype = torch.long).to(self.device)
		start_positions = torch.tensor([inp['start'] for inp in inputs], dtype = torch.long).to(self.device)
		end_positions = torch.tensor([inp['end'] for inp in inputs], dtype = torch.long).to(self.device)
		input_ids2 = torch.tensor([inp['input_tokens'] for inp in inputs2], dtype = torch.long).to(self.device)
		input_mask2 = torch.tensor([inp['input_mask'] for inp in inputs2], dtype = torch.long).to(self.device)
		outputs = self.pretrained_model(input_ids, attention_mask = input_mask)
		outputs2 = self.pretrained_model2(input_ids2, attention_mask = input_mask2)
		sequence_output = outputs[0]
		sequence_output2 = outputs2[0]
		query = self.q(sequence_output)
		concat = torch.cat((sequence_output, sequence_output2), dim = 1)
		concat_mask = torch.cat((1-input_mask, 1-input_mask2), dim = 1)		
		key = self.k(concat)
		value = self.v(concat)
		attn_output, attn_output_weights = self.multihead_attn(query, key, value, key_padding_mask=concat_mask)
		sequence_output = self.op(attn_output)
		logits = self.qa_outputs(sequence_output)
		start_logits, end_logits = logits.split(1, dim=-1)
		start_logits = start_logits.squeeze(-1)
		end_logits = end_logits.squeeze(-1)
		results = {}
		results['start_logits'] = start_logits
		results['end_logits'] = end_logits 
		if train:
			if len(start_positions.size()) > 1:
				start_positions = start_positions.squeeze(-1)
			if len(end_positions.size()) > 1:
				end_positions = end_positions.squeeze(-1)
			loss_fct = nn.CrossEntropyLoss()
			start_loss = loss_fct(start_logits, start_positions)
			end_loss = loss_fct(end_logits, end_positions)
			total_loss = (start_loss + end_loss) / 2
			results['loss'] = total_loss
		return results

	def update(self, loss, optimizer, step):
		loss = loss.mean()
		
		loss.backward()
		
		
		if (step + 1) % self.config['gradient_accumulation_steps']:
			grad_norm = nn.utils.clip_grad_norm_(self.parameters(), self.config['grad_clip'])
			optimizer.step()
			optimizer.zero_grad()

	def evaluate(self, score_s, score_e, paragraphs, answers, debug = False):
	    if score_s.size(0) > 1:
	        score_s = score_s.exp().squeeze()
	        score_e = score_e.exp().squeeze()
	    else:
	        score_s = score_s.exp()
	        score_e = score_e.exp()
	    predictions = []
	    spans = []
	    for i, (_s, _e) in enumerate(zip(score_s, score_e)):
	        _s = _s.view(1, -1)
	        _e = _e.view(1, -1)
	        prediction, span = self._scores_to_text(paragraphs[i], _s, _e)
	        predictions.append(prediction)
	        spans.append(span)
	    answers = [[' '.join(a)] for a in answers]
	    f1, em = self.evaluate_predictions(predictions, answers)
	    return f1, em, predictions

	def _scores_to_text(self, text, score_s, score_e):
	    max_len = score_s.size(1)
	    scores = torch.ger(score_s.squeeze(), score_e.squeeze())
	    scores.triu_().tril_(max_len - 1)
	    scores = scores.cpu().detach().numpy()
	    s_idx, e_idx = np.unravel_index(np.argmax(scores), scores.shape)
	    return ' '.join(text[s_idx: e_idx + 1]), (int(s_idx), int(e_idx))
	def evaluate_predictions(self,predictions, answers):
	    f1_score = compute_eval_metric('f1', predictions, answers)
	    em_score = compute_eval_metric('em', predictions, answers)
	    return f1_score, em_score